#import <Cocoa/Cocoa.h>

//! Project version number for SourceryRuntime.
FOUNDATION_EXPORT double SourceryRuntimeVersionNumber;

//! Project version string for SourceryRuntime.
FOUNDATION_EXPORT const unsigned char SourceryRuntimeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SourceryRuntime/PublicHeader.h>


