 extern const unsigned char SourceryRuntimeVersionString[];
 extern const double SourceryRuntimeVersionNumber;

 const unsigned char SourceryRuntimeVersionString[] __attribute__ ((used)) = "@(#)PROGRAM:SourceryRuntime  PROJECT:Sourcery-1" "\n";
 const double SourceryRuntimeVersionNumber __attribute__ ((used)) = (double)1.;
